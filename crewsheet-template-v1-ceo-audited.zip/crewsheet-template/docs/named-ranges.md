# Named Ranges Reference

The included `.xlsx` template is designed to convert cleanly into Google Sheets. After uploading to Google Sheets, named ranges can be created manually if you want more durable formulas or future Apps Script extensions.

Recommended named ranges:

| Name | Range |
|---|---|
| CustomersTable | Customers!A1:K100 |
| JobsTable | Jobs!A1:R100 |
| QuotesTable | Quotes!A1:Q100 |
| SuppliesTable | Supplies!A1:K100 |
| PaymentsTable | Payments!A1:L100 |
| SettingsTable | Settings!A1:C100 |
| BusinessName | Settings!B2 |
| BusinessEmail | Settings!B3 |
| BusinessPhone | Settings!B4 |
| DefaultTaxRate | Settings!B5 |
| SundaySummaryRecipient | Settings!B9 |
| SupportEmail | Settings!B11 |
| CurrencySymbol | Settings!B12 |
| TestMode | Settings!B13 |
| BlockPlaceholderPaymentLinks | Settings!B14 |
| LaunchApproved | Settings!B15 |

## How to add in Google Sheets

1. Open the copied Google Sheet.
2. Select the target range.
3. Click `Data -> Named ranges`.
4. Enter the name.
5. Click Done.

The v1 Apps Script does not require named ranges. It reads by sheet name and header names so customers can still use the product without setting these manually.
