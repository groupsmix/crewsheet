# Seller Launch Runbook

This is the seller-side operating procedure for turning the ZIP package into a live paid product.

## 1. Create the master Google Sheet

1. Upload `template/CrewSheet-v1-template.xlsx` to Google Drive.
2. Open it with Google Sheets.
3. Rename it `CrewSheet v1 Template`.
4. Confirm all six tabs are present.
5. Confirm formulas and dropdowns survived conversion.
6. Keep the master copy clean; do not add real customer data.

## 2. Install the script in the master copy

1. Open `Extensions -> Apps Script`.
2. Paste `apps-script/Code.gs`.
3. Use `apps-script/appsscript.json` as the project setting reference.
4. Save.
5. Reload the Sheet.
6. Run `CrewSheet -> Install / Refresh Triggers`.
7. Run `CrewSheet -> Run Health Check`.

## 3. Replace seller placeholders

In the master copy, update Settings:

- Business Name
- Business Email
- Business Phone
- Default Tax Rate
- Default Currency
- Quote Email Subject
- Quote Email Footer
- Sunday Summary Recipient
- Stripe Payment Link Base URL
- Support Email
- Currency Symbol

Keep these until final testing is complete:

- Test Mode = TRUE
- Block Placeholder Payment Links = TRUE
- Launch Approved? = FALSE

## 4. Test quote sending

1. Add a test customer using an email you control.
2. Create a quote.
3. Run `CrewSheet -> Send Selected Quote` while Test Mode is TRUE.
4. Confirm the email goes to Business Email.
5. Set Test Mode to FALSE.
6. Send one quote to an email you control.
7. Set Test Mode back to TRUE in the master copy before sharing it as a template.

## 5. Record the Loom walkthrough

Use `docs/loom-walkthrough-script.md`.

Required scenes:

- Make a copy.
- Fill Settings.
- Install Apps Script.
- Run Health Check.
- Send a test quote in Test Mode.
- Turn Test Mode off for real customer sends.
- Track payment.
- Send Sunday summary.

## 6. Create buyer-facing links

Prepare URLs for:

- Google Sheet template link.
- Setup checklist.
- Loom walkthrough.
- Glide/AppSheet runbook.
- Customer license.
- Support email.

The Google Sheet should be shared as `Anyone with the link: Viewer`.

## 7. Wire commerce and fulfillment

1. Create Stripe Payment Link for DIY.
2. Create Stripe Payment Link for DFY if selling it.
3. Create webhook for `checkout.session.completed`.
4. Verify Stripe webhook signature.
5. Send buyer delivery email through Resend.
6. Test using Stripe test card.
7. Confirm every delivery link opens from a clean browser profile.

## 8. Run the final CEO gate

Complete `docs/launch-readiness-checklist.md`.

Only after every item passes:

1. Set `Launch Approved?` to `TRUE` in the seller's launch-control copy.
2. Switch Stripe to live mode.
3. Run one live internal purchase.
4. Launch only to a small controlled audience first.

## Recommended launch sequence

1. Internal test.
2. 5 friendly cleaning-business users.
3. 10-30 soft-launch buyers.
4. Collect real testimonials and support issues.
5. Public launch.

Do not run paid ads or affiliate traffic before the soft launch produces successful buyer setups.
