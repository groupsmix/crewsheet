# Loom Walkthrough Script

Title: How to Set Up CrewSheet in 60 Minutes

Target length: 15 minutes.

## 0:00 - Intro

"Welcome to CrewSheet. In this walkthrough, I will show you how to copy the template, set up your cleaning business settings, run the health check, send a safe test quote, track payment, and check your weekly summary."

## 1:00 - Make a copy

Show:

1. Opening the template link.
2. Clicking `File -> Make a copy`.
3. Renaming the Sheet.

Say:

"Do not edit the original template. Always make your own copy first."

## 2:30 - Settings

Show the Settings tab.

Fill:

- Business Name
- Business Email
- Business Phone
- Default Tax Rate
- Quote Email Subject
- Sunday Summary Recipient
- Test Mode
- Block Placeholder Payment Links

Say:

"Most automation pulls from this Settings tab. Keep Test Mode set to TRUE until you have sent a test quote to your own business email."

## 4:00 - Customers

Add one fake customer.

Explain:

- Customer ID format.
- Preferred contact.
- Customer type.

## 5:30 - Jobs

Add one fake job.

Explain:

- Job ID format.
- Status dropdown.
- Service type dropdown.
- Base Price and Add-ons.
- Total Price formula.

## 7:00 - Quotes

Create one quote.

Explain:

- Quote ID.
- Customer ID.
- Job ID.
- Tax.
- Total Quote.
- Stripe Link placeholder.
- Quote Status.

## 9:00 - Apps Script install

Show:

1. Extensions -> Apps Script.
2. Code file.
3. Save.
4. Return to Sheet.
5. Reload.
6. CrewSheet -> Install / Refresh Triggers.
7. Authorization.

Say:

"Google may show an unverified-app screen because this is your own private copied script. Continue only if you copied it from your CrewSheet package."

## 11:00 - Run health check and send selected quote

Show:

1. CrewSheet -> Run Health Check.
2. Select quote row.
3. Confirm Test Mode is TRUE.
4. CrewSheet -> Send Selected Quote.
5. Confirmation message.
6. Email arrives at Business Email, not customer email.

Say:

"This safety step prevents accidental real-customer emails during setup. Turn Test Mode to FALSE only after testing."

## 12:30 - Payments

Show:

- Add payment row.
- Amount Due.
- Amount Paid.
- Balance.
- Payment Status.

## 13:30 - Supplies

Show:

- Current Quantity.
- Minimum Quantity.
- Reorder Needed?

## 14:15 - Sunday Summary

Show:

- CrewSheet -> Send Sunday Summary Now.
- Email received.

## 15:00 - Close

"That is the core CrewSheet setup. You can now run customer tracking, job tracking, quoting, payments, supplies, and weekly summary emails from one Google Sheet."
