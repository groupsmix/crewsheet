# CrewSheet Mobile App Setup: Glide or AppSheet

CrewSheet v1 does not include a redistributed mobile app. This document gives customers a recipe to create their own private mobile app from their copied Google Sheet.

## Option A: Glide

1. Go to Glide.
2. Create a new app.
3. Choose Google Sheets as the data source.
4. Select your copied CrewSheet file.
5. Add visible tabs:
   - Customers
   - Jobs
   - Quotes
   - Payments
6. Make `Jobs` the main/home screen.
7. Create forms:
   - New Customer
   - New Job
   - New Quote
   - New Payment
8. Hide `Settings` from normal app users.
9. Test on your phone.
10. Add the app shortcut to your phone home screen.

Recommended Glide screens:

- Today / Upcoming Jobs
- Customers
- Quotes
- Payments
- Supplies

## Option B: AppSheet

1. Go to AppSheet.
2. Create app from Google Sheets.
3. Select your copied CrewSheet file.
4. Confirm AppSheet detected all six tabs.
5. Set these views as visible:
   - Customers
   - Jobs
   - Quotes
   - Payments
6. Hide:
   - Settings
7. Create quick actions:
   - Add customer
   - Add job
   - Mark job completed
   - Mark payment paid
8. Test with one fake customer before using live customer data.

## Important limits

- Glide/AppSheet billing is separate from CrewSheet.
- This is a recipe, not a hosted app.
- The customer owns their copied Sheet and app setup.
- Do not use this to promise SMS, customer portal, or advanced dispatch features in v1.
