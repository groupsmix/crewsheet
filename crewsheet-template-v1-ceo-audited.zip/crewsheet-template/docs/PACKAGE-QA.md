# Package QA Notes

Date: 2026-05-12

## Checks completed

- ZIP unpacked and every packaged file reviewed.
- Apps Script syntax checked with Node after copying `.gs` to `.js` for syntax parsing.
- Workbook imported and inspected.
- Workbook sheet list verified:
  - Customers
  - Jobs
  - Quotes
  - Supplies
  - Payments
  - Settings
- Workbook formula-error scan found no `#REF!`, `#DIV/0!`, `#VALUE!`, `#NAME?`, or `#N/A` values.
- CSV files parsed successfully with consistent column counts.
- Buyer docs updated to emphasize Test Mode and placeholder replacement.

## Known limits

These require the seller's real accounts and cannot be validated inside this ZIP:

- Google Sheets conversion behavior in the seller's Google Drive.
- Apps Script authorization flow in the seller's Google account.
- Real MailApp delivery behavior.
- Stripe live Payment Links.
- Stripe webhook + Resend fulfillment.
- Loom video URL.
- Legal review.

## Required manual test before selling

1. Upload the `.xlsx` to Google Drive.
2. Convert to Google Sheets.
3. Paste `apps-script/Code.gs`.
4. Reload the Sheet.
5. Install triggers.
6. Run Health Check.
7. Confirm Test Mode is TRUE.
8. Send selected quote and confirm it goes to Business Email.
9. Remove placeholder payment links.
10. Set Test Mode to FALSE and send one quote to an email you control.
