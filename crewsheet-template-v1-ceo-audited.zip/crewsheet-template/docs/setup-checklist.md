# CrewSheet Setup Checklist

Goal: set up CrewSheet in 60 minutes or less without accidentally emailing real customers during testing.

## Before you start

You need:

- A Google account.
- Access to the CrewSheet template link.
- Your business email.
- Your customer support email.
- Your payment link, if you already use Stripe, Square, Gumroad, Lemon Squeezy, or another checkout tool.

## Step 1: Make a copy of the Sheet

1. Open the CrewSheet template link.
2. Click `File -> Make a copy`.
3. Name it `[Your Business Name] CrewSheet`.
4. Save it in your Google Drive.

Do not edit the original template.

## Step 2: Fill in Settings

Open the `Settings` tab and complete:

- Business Name
- Business Email
- Business Phone
- Default Tax Rate
- Default Currency
- Quote Email Subject
- Quote Email Footer
- Sunday Summary Recipient
- Stripe Payment Link Base URL
- Support Email
- Currency Symbol

Keep these safety settings during testing:

- `Test Mode` = `TRUE`
- `Block Placeholder Payment Links` = `TRUE`
- `Launch Approved?` = `FALSE`

Use decimal format for tax rate.

Examples:

- `0` for no automatic tax
- `0.0825` for 8.25%

## Step 3: Install the automation

1. Open `Extensions -> Apps Script`.
2. Paste the included `apps-script/Code.gs` if it is not already there.
3. Click Save.
4. Return to the Sheet.
5. Reload the page.
6. Click `CrewSheet -> Install / Refresh Triggers`.
7. Approve the Google permission prompts.
8. Click `CrewSheet -> Run Health Check`.

Expected result:

- A Sunday summary email trigger is installed.
- The CrewSheet menu is visible in the Sheet.
- Health Check shows no blocking errors.

## Step 4: Add your first test customer

Open `Customers` and add a test customer using an email address you control.

Required fields:

- Customer ID
- Customer Name
- Phone
- Email
- Address
- City
- Preferred Contact
- Customer Type

Recommended ID format:

- `CUST-001`
- `CUST-002`
- `CUST-003`

Do not add live customer data until you finish the test send.

## Step 5: Add your first job

Open `Jobs` and add:

- Job ID
- Customer ID
- Customer Name
- Service Date
- Service Time
- Service Type
- Address
- Status
- Cleaner Assigned
- Estimated Hours
- Base Price
- Add-ons

Recommended ID format:

- `JOB-001`
- `JOB-002`
- `JOB-003`

The Total Price column calculates automatically for sample rows, and Apps Script recalculates edited rows.

## Step 6: Create your first quote

Open `Quotes` and add:

- Quote ID
- Customer ID
- Job ID
- Quote Date
- Service Type
- Base Price
- Add-ons
- Discount
- Stripe Link, if available

Recommended ID format:

- `Q-001`
- `Q-002`
- `Q-003`

The Tax and Total Quote columns calculate automatically for sample rows, and Apps Script recalculates before sending.

Important: remove any `placeholder` payment link before sending a real customer quote.

## Step 7: Send a test quote email

1. Keep `Settings -> Test Mode` set to `TRUE`.
2. Open `Quotes`.
3. Click any cell in the quote row.
4. Click `CrewSheet -> Send Selected Quote`.
5. Confirm the email goes to your Business Email, not the customer.
6. Confirm the email content looks correct.

Test Mode protects you from accidentally sending a quote to a real customer.

## Step 8: Turn on real customer sending only after testing

After you complete the test:

1. Change `Settings -> Test Mode` to `FALSE`.
2. Keep `Block Placeholder Payment Links` as `TRUE`.
3. Use only a real payment link or leave the Stripe Link cell blank.
4. Send one real test to an email you control before using a real customer email.

## Step 9: Track payment

Open `Payments` and add:

- Payment ID
- Customer ID
- Job ID
- Invoice Date
- Amount Due
- Amount Paid
- Payment Method
- Payment Status
- Stripe Link

The Balance column calculates automatically for sample rows, and Apps Script recalculates edited rows.

## Step 10: Track supplies

Open `Supplies` and add:

- Item Name
- Category
- Current Quantity
- Minimum Quantity
- Unit
- Cost Per Unit
- Preferred Vendor

The Reorder Needed? column updates automatically for sample rows, and Apps Script recalculates edited rows.

## Step 11: Confirm Sunday summary

To test immediately:

1. Click `CrewSheet -> Send Sunday Summary Now`.
2. Check the email address in `Settings -> Sunday Summary Recipient`.

The automatic summary sends weekly on Sunday morning after you install triggers.

## Troubleshooting

### I do not see the CrewSheet menu

Reload the Sheet. If it still does not appear, open Apps Script and make sure `Code.gs` is saved.

### Google says the app is not verified

That is normal for your private copied Sheet. Click through the advanced option only if you trust the script and you copied it from your purchased CrewSheet package.

### Quote email does not send

Check:

- Customer ID in Quotes matches Customer ID in Customers.
- Customer row has a valid Email.
- Total Quote is greater than 0.
- Stripe Link does not contain `placeholder` or `example.com`.
- You authorized the script.
- You selected the quote row before clicking send.

### Quote email goes to my business email instead of the customer

`Test Mode` is still `TRUE`. This is intentional during setup. Change it to `FALSE` only after you finish testing.

### Sunday summary does not send

Click `CrewSheet -> Install / Refresh Triggers` again, then use `CrewSheet -> Send Sunday Summary Now` to test manually.
