Subject: Your CrewSheet v1 template is ready

Hi {{customer_first_name}},

Thank you for purchasing CrewSheet.

Here are your setup links:

1. CrewSheet Google Sheet template:
{{google_sheet_template_link}}

2. Setup checklist:
{{setup_checklist_link}}

3. 15-minute setup walkthrough:
{{loom_walkthrough_link}}

4. Mobile app recipe for Glide/AppSheet:
{{glide_appsheet_runbook_link}}

5. Customer license:
{{customer_license_link}}

## Recommended setup order

1. Open the Google Sheet template.
2. Click `File -> Make a copy`.
3. Fill the `Settings` tab.
4. Keep `Test Mode` set to `TRUE` while testing.
5. Add one test customer using an email address you control.
6. Add one test job.
7. Create one test quote.
8. Install the CrewSheet script.
9. Run `CrewSheet -> Run Health Check`.
10. Send one test quote to your Business Email.
11. Replace sample data with your real business data.
12. Set `Test Mode` to `FALSE` only when you are ready to send quotes to real customers.

## Need help?

Email {{support_email}} with:

- Your order email
- A short description of the issue
- A screenshot if possible

Important: CrewSheet is a digital template and setup guide. It is not legal, tax, accounting, financial, or business advice. You own and control the customer data you put into your copied Google Sheet.

Thanks,
{{founder_name}}
CrewSheet
