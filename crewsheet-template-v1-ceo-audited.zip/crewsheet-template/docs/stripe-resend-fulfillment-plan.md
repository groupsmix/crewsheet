# Stripe + Resend Fulfillment Plan

This file explains how to wire the sellable product after the template is ready.

## Minimum production flow

1. Customer buys DIY product through Stripe Payment Link.
2. Stripe sends `checkout.session.completed` webhook.
3. Your webhook verifies Stripe signature.
4. Your webhook checks idempotency so the same Stripe event does not send duplicate delivery emails.
5. Webhook sends buyer email through Resend.
5. Buyer receives:
   - Google Sheet template link
   - Setup checklist
   - Loom walkthrough
   - License
   - Support email

## Required placeholders

Replace these before public launch:

- `{{stripe_diy_payment_link}}`
- `{{stripe_dfy_payment_link}}`
- `{{google_sheet_template_link}}`
- `{{loom_walkthrough_link}}`
- `{{support_email}}`
- `{{founder_name}}`

## Test checklist

- Buy with Stripe test card.
- Confirm Stripe event arrives.
- Confirm buyer email sends exactly once.
- Resend the same webhook event and confirm idempotency prevents duplicate delivery.
- Confirm all links open.
- Confirm Sheet is viewer-only.
- Confirm buyer can make a copy.
- Confirm support email is correct.
- Confirm refund policy is linked.

## Manual fallback

If automation fails, manually send `docs/buyer-delivery-email.md` to the buyer within 24 hours.

## Do not launch until

- Stripe links work in live mode.
- Delivery email works in live mode.
- Duplicate Stripe webhooks do not send duplicate customer emails.
- Delivery links open from a clean/incognito browser.
- Legal/refund copy is reviewed.
- Support inbox is active.
- Google Sheet link is correct.

## Webhook safety requirements

- Verify the `stripe-signature` header.
- Store processed Stripe event IDs to prevent duplicate delivery.
- Do not trust client-side checkout success pages for fulfillment.
- Log delivery failures and manually follow up within 24 hours.
- Never include private Google Drive edit links in the buyer email; use viewer-only template links.
