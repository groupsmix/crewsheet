# Launch Readiness Checklist

Use this as the final CEO gate before public launch.

## Product

- [ ] Google Sheet has exactly six business tabs: Customers, Jobs, Quotes, Supplies, Payments, Settings.
- [ ] Sample data is fake and clearly not testimonial/proof.
- [ ] Formulas work after Google Sheets conversion.
- [ ] Dropdowns work after Google Sheets conversion.
- [ ] Apps Script pasted and saved.
- [ ] CrewSheet menu appears after reload.
- [ ] `CrewSheet -> Install / Refresh Triggers` succeeds.
- [ ] `CrewSheet -> Run Health Check` runs.
- [ ] Test quote sends to Business Email while Test Mode is TRUE.
- [ ] Real quote send is tested only with an email you control after Test Mode is FALSE.
- [ ] Quote sending blocks placeholder payment links.
- [ ] Sunday summary sends.
- [ ] Setup completed by a non-technical tester in under 60 minutes.

## Zero-placeholder gate

- [ ] No `{{google_sheet_template_link}}` placeholder remains in customer-facing assets.
- [ ] No `{{loom_walkthrough_link}}` placeholder remains in customer-facing assets.
- [ ] No `{{support_email}}` placeholder remains in live delivery workflow.
- [ ] No placeholder Stripe links are sent to customers.
- [ ] No `example.com` emails are used in live materials.
- [ ] Founder name and business contact details are real.

## Commerce

- [ ] Stripe DIY payment link created.
- [ ] Stripe DFY payment link created.
- [ ] Checkout copy matches landing page.
- [ ] Test purchase completed.
- [ ] Live purchase completed with small internal test.
- [ ] Refund policy is visible before checkout.

## Fulfillment

- [ ] Delivery email sends automatically.
- [ ] Delivery email includes correct links.
- [ ] Delivery email links open without requiring seller permissions.
- [ ] Google Sheet template is viewer-only.
- [ ] Buyer can make a copy from a clean Google account.
- [ ] Loom walkthrough recorded.
- [ ] Customer license linked.
- [ ] Support email active.
- [ ] Manual fallback email process documented.

## Legal

- [ ] Privacy page reviewed.
- [ ] Terms page reviewed.
- [ ] Refund page reviewed.
- [ ] Customer license reviewed.
- [ ] Data-processing language reviewed if needed.
- [ ] Warranty disclaimers reviewed.
- [ ] Revenue/savings claims reviewed or removed.

## Marketing

- [ ] No fake testimonials.
- [ ] No SMS claims in v1.
- [ ] No Pro-tier claims in v1.
- [ ] Pricing is accurate.
- [ ] Founder/contact info is real.
- [ ] Site has production domain.
- [ ] Sitemap submitted.
- [ ] Analytics configured after consent review.

## CEO launch gate

Launch only if all are true:

- [ ] Product deliverable exists.
- [ ] Customer can receive it after purchase.
- [ ] Customer can set it up.
- [ ] Customer can safely test before sending real emails.
- [ ] Legal risk is reviewed.
- [ ] Support path exists.
- [ ] `Settings -> Launch Approved?` is intentionally set to TRUE in the seller's master copy after all checks pass.
