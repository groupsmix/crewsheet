# Done-For-You Onboarding Checklist

Use this for the $497 DFY offer.

## Before the call

Collect only the minimum information needed. Do not request passwords, bank logins, or unnecessary customer personal data.

Collect from customer:

- Business name
- Business email
- Business phone
- City/region served
- Service types
- Pricing rules
- Tax rate, if any
- Payment link provider
- Existing customer list, if any, preferably limited to active customers
- Existing job list, if any, preferably limited to active/upcoming jobs
- Logo, if available

## Intake questions

1. What cleaning services do you offer?
2. Do you serve residential, commercial, Airbnb, move-out, or all of these?
3. How do you currently quote jobs?
4. How do customers pay you?
5. Who should receive weekly summaries?
6. Do you need one cleaner view or owner-only access?
7. Do you want a Glide/AppSheet mobile version?

## Setup workflow

1. Make a private copy of the CrewSheet template.
2. Rename it: `[Customer Business Name] CrewSheet`.
3. Fill Settings.
4. Add service/pricing examples.
5. Import customer list.
6. Import active jobs.
7. Add payment links if available.
8. Install Apps Script.
9. Keep Test Mode TRUE during setup.
10. Run Health Check.
11. Send test quote to the customer's business email first.
12. Send one approved real test quote only after customer confirms.
13. Send test Sunday summary to customer.
14. Walk customer through the Sheet on a video call.

## Handoff checklist

- Customer has copied/owned Sheet.
- Customer can access Sheet.
- Customer can add customer.
- Customer can add job.
- Customer can create quote.
- Customer can send quote email.
- Customer understands Test Mode and how to disable it after testing.
- Customer understands placeholder payment links are blocked.
- Customer can update payment.
- Customer understands Sunday summary.
- Customer understands no SMS in v1.
- Customer has setup recording or Loom.
- Customer has support email.

## Post-handoff email

Subject: Your CrewSheet DFY setup is complete

Hi {{customer_first_name}},

Your CrewSheet setup is complete.

Sheet:
{{customer_sheet_link}}

What we configured:

- Business settings
- Customer tracking
- Job tracking
- Quote tracking
- Payment tracking
- Supply tracking
- Email automation
- Sunday summary

Recommended next step:

Add your next real customer and job today so CrewSheet becomes part of your normal workflow.

Thanks,
{{founder_name}}
