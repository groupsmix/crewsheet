# Changelog

## v1.0.1 - CEO audit hardening

Fixed after senior CEO review:

- Added safe `Test Mode` setting so first quote emails go to the business email, not real customers.
- Added `Block Placeholder Payment Links` setting to prevent sending quotes with placeholder URLs.
- Added `Launch Approved?` setting as an explicit launch gate.
- Added `Currency Symbol` setting for email summaries and quote emails.
- Strengthened Apps Script validation, customer email checks, confirmation prompts, and health check.
- Updated Sunday summary to recalculate before sending.
- Updated CSV versions with formulas and the new safety settings.
- Added seller launch runbook and CEO audit report.
- Updated setup docs to prevent accidental real-customer sends during testing.

## v1.0.0 - Initial sellable template package

Included:

- Six-tab CrewSheet workbook.
- Apps Script v1 automation.
- Buyer setup checklist.
- Glide/AppSheet recipe.
- Loom walkthrough script.
- Buyer delivery email.
- DFY onboarding checklist.
- Stripe + Resend fulfillment plan.
- Customer license draft.
