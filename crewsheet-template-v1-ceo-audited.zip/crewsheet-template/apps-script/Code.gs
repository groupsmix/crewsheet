/**
 * CrewSheet v1 Apps Script
 * Scope: email-only automation for the DIY Google Sheet template.
 * SMS/Twilio is intentionally excluded from v1.
 *
 * Safety posture:
 * - Test Mode defaults to TRUE in Settings so first quote emails go to the business email.
 * - Real customer sends require confirmation.
 * - Placeholder payment links are blocked when Block Placeholder Payment Links is TRUE.
 */

const CREWSHEET = {
  SHEETS: {
    CUSTOMERS: 'Customers',
    JOBS: 'Jobs',
    QUOTES: 'Quotes',
    SUPPLIES: 'Supplies',
    PAYMENTS: 'Payments',
    SETTINGS: 'Settings',
  },
  MENU_NAME: 'CrewSheet',
  MAX_HEALTH_ROWS: 200,
};

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu(CREWSHEET.MENU_NAME)
    .addItem('Install / Refresh Triggers', 'installCrewSheet')
    .addItem('Run Health Check', 'runHealthCheck')
    .addSeparator()
    .addItem('Send Selected Quote', 'sendSelectedQuote')
    .addItem('Send Selected Quote to Business Email', 'sendSelectedQuoteToBusinessEmail')
    .addItem('Send Sunday Summary Now', 'sendSundaySummary')
    .addSeparator()
    .addItem('Recalculate Everything', 'recalculateEverything')
    .addItem('Recalculate Job Totals', 'recalculateJobTotals')
    .addItem('Recalculate Quote Totals', 'recalculateQuoteTotals')
    .addItem('Recalculate Payment Balances', 'recalculatePaymentBalances')
    .addToUi();
}

/**
 * Run once after copying the Sheet.
 */
function installCrewSheet() {
  deleteCrewSheetTriggers_();

  ScriptApp.newTrigger('sendSundaySummary')
    .timeBased()
    .onWeekDay(ScriptApp.WeekDay.SUNDAY)
    .atHour(9)
    .create();

  SpreadsheetApp.getUi().alert(
    'CrewSheet installed',
    'Sunday summary trigger is active for Sundays around 9 AM. Run CrewSheet -> Run Health Check before sending real customer quotes.',
    SpreadsheetApp.getUi().ButtonSet.OK
  );
}

function deleteCrewSheetTriggers_() {
  ScriptApp.getProjectTriggers().forEach(trigger => {
    const fn = trigger.getHandlerFunction();
    if (['sendSundaySummary'].includes(fn)) {
      ScriptApp.deleteTrigger(trigger);
    }
  });
}

function onEdit(e) {
  if (!e || !e.range) return;

  const sheet = e.range.getSheet();
  const sheetName = sheet.getName();
  const watchedSheets = [
    CREWSHEET.SHEETS.CUSTOMERS,
    CREWSHEET.SHEETS.JOBS,
    CREWSHEET.SHEETS.QUOTES,
    CREWSHEET.SHEETS.SUPPLIES,
    CREWSHEET.SHEETS.PAYMENTS,
  ];

  if (!watchedSheets.includes(sheetName)) return;

  const firstRow = Math.max(e.range.getRow(), 2);
  const lastRow = e.range.getLastRow();

  for (let row = firstRow; row <= lastRow; row++) {
    stampLastUpdated_(sheet, row);

    if (sheetName === CREWSHEET.SHEETS.JOBS) recalculateJobRow_(sheet, row);
    if (sheetName === CREWSHEET.SHEETS.QUOTES) recalculateQuoteRow_(sheet, row);
    if (sheetName === CREWSHEET.SHEETS.PAYMENTS) recalculatePaymentRow_(sheet, row);
    if (sheetName === CREWSHEET.SHEETS.SUPPLIES) recalculateSupplyRow_(sheet, row);
  }
}

function recalculateEverything() {
  recalculateJobTotals();
  recalculateQuoteTotals();
  recalculatePaymentBalances();
  recalculateSupplyReorderChecks_();
  SpreadsheetApp.getUi().alert('CrewSheet recalculation complete.');
}

function stampLastUpdated_(sheet, row) {
  const headers = getHeaders_(sheet);
  const col = headers.indexOf('Last Updated') + 1;
  if (col > 0 && row > 1) sheet.getRange(row, col).setValue(new Date());
}

function recalculateJobTotals() {
  const sheet = getSheet_(CREWSHEET.SHEETS.JOBS);
  const lastRow = sheet.getLastRow();
  for (let row = 2; row <= lastRow; row++) recalculateJobRow_(sheet, row);
}

function recalculateJobRow_(sheet, row) {
  const headers = getHeaders_(sheet);
  const baseCol = headers.indexOf('Base Price') + 1;
  const addonsCol = headers.indexOf('Add-ons') + 1;
  const totalCol = headers.indexOf('Total Price') + 1;
  if (!baseCol || !addonsCol || !totalCol) return;

  const base = toNumber_(sheet.getRange(row, baseCol).getValue());
  const addons = toNumber_(sheet.getRange(row, addonsCol).getValue());
  if (base || addons) sheet.getRange(row, totalCol).setValue(base + addons);
}

function recalculateQuoteTotals() {
  const sheet = getSheet_(CREWSHEET.SHEETS.QUOTES);
  const lastRow = sheet.getLastRow();
  for (let row = 2; row <= lastRow; row++) recalculateQuoteRow_(sheet, row);
}

function recalculateQuoteRow_(sheet, row) {
  const headers = getHeaders_(sheet);
  const baseCol = headers.indexOf('Base Price') + 1;
  const addonsCol = headers.indexOf('Add-ons') + 1;
  const discountCol = headers.indexOf('Discount') + 1;
  const taxCol = headers.indexOf('Tax') + 1;
  const totalCol = headers.indexOf('Total Quote') + 1;
  if (!baseCol || !addonsCol || !discountCol || !taxCol || !totalCol) return;

  const base = toNumber_(sheet.getRange(row, baseCol).getValue());
  const addons = toNumber_(sheet.getRange(row, addonsCol).getValue());
  const discount = toNumber_(sheet.getRange(row, discountCol).getValue());
  const taxRate = toNumber_(getSetting_('Default Tax Rate'));
  if (!base && !addons && !discount) return;

  const subtotal = Math.max(0, base + addons - discount);
  const tax = subtotal * taxRate;
  sheet.getRange(row, taxCol).setValue(tax);
  sheet.getRange(row, totalCol).setValue(subtotal + tax);
}

function recalculatePaymentBalances() {
  const sheet = getSheet_(CREWSHEET.SHEETS.PAYMENTS);
  const lastRow = sheet.getLastRow();
  for (let row = 2; row <= lastRow; row++) recalculatePaymentRow_(sheet, row);
}

function recalculatePaymentRow_(sheet, row) {
  const headers = getHeaders_(sheet);
  const dueCol = headers.indexOf('Amount Due') + 1;
  const paidCol = headers.indexOf('Amount Paid') + 1;
  const balanceCol = headers.indexOf('Balance') + 1;
  const statusCol = headers.indexOf('Payment Status') + 1;
  if (!dueCol || !paidCol || !balanceCol || !statusCol) return;

  const due = toNumber_(sheet.getRange(row, dueCol).getValue());
  const paid = toNumber_(sheet.getRange(row, paidCol).getValue());
  if (!due && !paid) return;

  const balance = Math.max(0, due - paid);
  sheet.getRange(row, balanceCol).setValue(balance);

  if (balance === 0 && due > 0) sheet.getRange(row, statusCol).setValue('Paid');
  else if (paid > 0) sheet.getRange(row, statusCol).setValue('Partial');
  else sheet.getRange(row, statusCol).setValue('Unpaid');
}

function recalculateSupplyReorderChecks_() {
  const sheet = getSheet_(CREWSHEET.SHEETS.SUPPLIES);
  const lastRow = sheet.getLastRow();
  for (let row = 2; row <= lastRow; row++) recalculateSupplyRow_(sheet, row);
}

function recalculateSupplyRow_(sheet, row) {
  const headers = getHeaders_(sheet);
  const currentCol = headers.indexOf('Current Quantity') + 1;
  const minCol = headers.indexOf('Minimum Quantity') + 1;
  const reorderCol = headers.indexOf('Reorder Needed?') + 1;
  if (!currentCol || !minCol || !reorderCol) return;

  const currentQty = toNumber_(sheet.getRange(row, currentCol).getValue());
  const minimumQty = toNumber_(sheet.getRange(row, minCol).getValue());
  if (currentQty || minimumQty) sheet.getRange(row, reorderCol).setValue(currentQty <= minimumQty ? 'Yes' : 'No');
}

function sendSelectedQuote() {
  sendSelectedQuote_(false);
}

function sendSelectedQuoteToBusinessEmail() {
  sendSelectedQuote_(true);
}

function sendSelectedQuote_(forceBusinessEmail) {
  const ui = SpreadsheetApp.getUi();
  const ss = getSpreadsheet_();
  const sheet = ss.getActiveSheet();

  if (sheet.getName() !== CREWSHEET.SHEETS.QUOTES) {
    ui.alert('Go to the Quotes tab and select one quote row first.');
    return;
  }

  const row = sheet.getActiveCell().getRow();
  if (row === 1) {
    ui.alert('Select a quote row, not the header row.');
    return;
  }

  recalculateQuoteRow_(sheet, row);
  const quote = getRowObject_(sheet, row);
  const customer = getCustomerById_(quote['Customer ID']);
  const validation = validateQuoteForSend_(quote, customer);

  if (validation.errors.length) {
    ui.alert('Quote cannot be sent', validation.errors.join('\n'), ui.ButtonSet.OK);
    return;
  }

  if (validation.warnings.length) {
    const warnResult = ui.alert('Quote warning', validation.warnings.join('\n') + '\n\nContinue?', ui.ButtonSet.YES_NO);
    if (warnResult !== ui.Button.YES) return;
  }

  const businessEmail = String(getSetting_('Business Email') || '').trim();
  const testMode = isTrueSetting_('Test Mode');
  const sendToBusiness = forceBusinessEmail || testMode;
  const recipient = sendToBusiness ? businessEmail : String(customer['Email']).trim();

  if (!isValidEmail_(recipient)) {
    ui.alert('No valid recipient email found. Check Customer Email or Business Email in Settings.');
    return;
  }

  const subjectPrefix = sendToBusiness ? '[TEST] ' : '';
  const subject = subjectPrefix + (getSetting_('Quote Email Subject') || 'Your cleaning quote');
  const body = buildQuoteEmailBody_(quote, customer, sendToBusiness);

  const confirmMessage = sendToBusiness
    ? 'Send this TEST quote to ' + recipient + '? It will not be marked as sent to the customer.'
    : 'Send this quote to customer ' + recipient + '?';

  const confirm = ui.alert('Confirm quote email', confirmMessage, ui.ButtonSet.YES_NO);
  if (confirm !== ui.Button.YES) return;

  MailApp.sendEmail(recipient, subject, body);

  if (!sendToBusiness) {
    const headers = getHeaders_(sheet);
    const emailSentCol = headers.indexOf('Email Sent?') + 1;
    const statusCol = headers.indexOf('Quote Status') + 1;
    if (emailSentCol > 0) sheet.getRange(row, emailSentCol).setValue('Yes');
    if (statusCol > 0 && String(quote['Quote Status']).toLowerCase() === 'draft') sheet.getRange(row, statusCol).setValue('Sent');
  }

  ui.alert(sendToBusiness ? 'Test quote sent to ' + recipient : 'Quote sent to ' + recipient);
}

function validateQuoteForSend_(quote, customer) {
  const errors = [];
  const warnings = [];

  if (!quote['Quote ID']) errors.push('- Missing Quote ID.');
  if (!quote['Customer ID']) errors.push('- Missing Customer ID.');
  if (!customer) errors.push('- Customer ID was not found in Customers.');
  if (customer && !isValidEmail_(customer['Email'])) errors.push('- Customer Email is missing or invalid.');
  if (!quote['Service Type']) warnings.push('- Service Type is blank.');
  if (toNumber_(quote['Total Quote']) <= 0) errors.push('- Total Quote must be greater than 0.');

  const link = String(quote['Stripe Link'] || '').trim();
  if (isTrueSetting_('Block Placeholder Payment Links') && /placeholder|example\.com/i.test(link)) {
    errors.push('- Stripe Link still looks like a placeholder. Replace it or leave it blank.');
  }

  return { errors, warnings };
}

function buildQuoteEmailBody_(quote, customer, isTest) {
  const businessName = getSetting_('Business Name') || 'Your cleaning business';
  const businessEmail = getSetting_('Business Email') || '';
  const businessPhone = getSetting_('Business Phone') || '';
  const footer = getSetting_('Quote Email Footer') || 'Thank you.';
  const total = formatMoney_(quote['Total Quote']);
  const paymentLink = String(quote['Stripe Link'] || '').trim();

  const lines = [];
  if (isTest) lines.push('TEST MODE: This quote was sent to the business email, not the customer.');
  if (isTest) lines.push('');
  lines.push('Hi ' + (customer['Customer Name'] || 'there') + ',');
  lines.push('');
  lines.push('Here is your cleaning quote from ' + businessName + ':');
  lines.push('');
  lines.push('Quote ID: ' + (quote['Quote ID'] || ''));
  lines.push('Service: ' + (quote['Service Type'] || ''));
  lines.push('Total quote: ' + total);
  if (paymentLink) lines.push('Payment link: ' + paymentLink);
  lines.push('');
  lines.push(footer);
  lines.push('');
  if (businessPhone) lines.push('Phone: ' + businessPhone);
  if (businessEmail) lines.push('Email: ' + businessEmail);
  return lines.join('\n');
}

function sendSundaySummary() {
  recalculateJobTotals();
  recalculateQuoteTotals();
  recalculatePaymentBalances();
  recalculateSupplyReorderChecks_();

  const jobsSheet = getSheet_(CREWSHEET.SHEETS.JOBS);
  const paymentsSheet = getSheet_(CREWSHEET.SHEETS.PAYMENTS);
  const suppliesSheet = getSheet_(CREWSHEET.SHEETS.SUPPLIES);

  const recipient = getSetting_('Sunday Summary Recipient');
  if (!isValidEmail_(recipient)) throw new Error('Missing or invalid Sunday Summary Recipient in Settings.');

  const jobs = getDataObjects_(jobsSheet);
  const payments = getDataObjects_(paymentsSheet);
  const supplies = getDataObjects_(suppliesSheet);

  const today = new Date();
  const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
  const completedJobs = jobs.filter(job => job['Status'] === 'Completed');
  const scheduledJobs = jobs.filter(job => ['Requested', 'Quoted', 'Scheduled'].includes(job['Status']) && isDateWithin_(job['Service Date'], today, nextWeek));
  const unpaidPayments = payments.filter(payment => ['Unpaid', 'Partial'].includes(payment['Payment Status']));
  const reorderItems = supplies.filter(item => item['Reorder Needed?'] === 'Yes');

  const revenue = completedJobs.reduce((sum, job) => sum + toNumber_(job['Total Price']), 0);
  const balanceDue = unpaidPayments.reduce((sum, payment) => sum + toNumber_(payment['Balance']), 0);

  const body = [
    'CrewSheet Sunday Summary',
    '',
    'Completed jobs: ' + completedJobs.length,
    'Tracked completed-job revenue: ' + formatMoney_(revenue),
    'Upcoming/open jobs in next 7 days: ' + scheduledJobs.length,
    'Outstanding balance: ' + formatMoney_(balanceDue),
    'Supply items needing reorder: ' + reorderItems.length,
    '',
    'Upcoming / open jobs:',
    formatList_(scheduledJobs, job => `${formatDate_(job['Service Date'])} - ${job['Customer Name']} - ${job['Status']} - ${formatMoney_(job['Total Price'])}`),
    '',
    'Payments to follow up:',
    formatList_(unpaidPayments, payment => `${payment['Customer ID']} - ${payment['Job ID']} - ${payment['Payment Status']} - balance ${formatMoney_(payment['Balance'])}`),
    '',
    'Supplies to reorder:',
    formatList_(reorderItems, item => `${item['Item Name']} - current ${item['Current Quantity']} / min ${item['Minimum Quantity']}`),
  ].join('\n');

  MailApp.sendEmail(recipient, 'CrewSheet Sunday Summary', body);
}

function runHealthCheck() {
  const requiredSheets = Object.keys(CREWSHEET.SHEETS).map(key => CREWSHEET.SHEETS[key]);
  const errors = [];
  const warnings = [];

  requiredSheets.forEach(name => {
    try { getSheet_(name); } catch (err) { errors.push('- Missing sheet: ' + name); }
  });

  ['Business Name', 'Business Email', 'Sunday Summary Recipient', 'Support Email'].forEach(setting => {
    if (!getSetting_(setting)) errors.push('- Missing setting: ' + setting);
  });

  ['Business Email', 'Sunday Summary Recipient', 'Support Email'].forEach(setting => {
    const value = getSetting_(setting);
    if (value && !isValidEmail_(value)) errors.push('- Invalid email in setting: ' + setting);
  });

  if (String(getSetting_('Stripe Payment Link Base URL')).match(/placeholder|example\.com/i)) {
    warnings.push('- Stripe Payment Link Base URL still looks like a placeholder.');
  }
  if (isTrueSetting_('Test Mode')) warnings.push('- Test Mode is TRUE. Real customer quote sends will go to Business Email.');
  if (!isTrueSetting_('Launch Approved?')) warnings.push('- Launch Approved? is not TRUE. Do not public-launch yet.');

  const message = [
    errors.length ? 'ERRORS:' : 'ERRORS: None',
    errors.join('\n'),
    '',
    warnings.length ? 'WARNINGS:' : 'WARNINGS: None',
    warnings.join('\n'),
  ].join('\n').replace(/\n{3,}/g, '\n\n');

  SpreadsheetApp.getUi().alert(errors.length ? 'CrewSheet health check failed' : 'CrewSheet health check complete', message, SpreadsheetApp.getUi().ButtonSet.OK);
}

function getSpreadsheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('No active spreadsheet found. CrewSheet must be used as a bound script inside the template Sheet.');
  return ss;
}

function getSheet_(name) {
  const sheet = getSpreadsheet_().getSheetByName(name);
  if (!sheet) throw new Error('Missing sheet: ' + name);
  return sheet;
}

function getHeaders_(sheet) {
  return sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
}

function getDataObjects_(sheet) {
  const range = sheet.getDataRange();
  const values = range.getValues();
  if (values.length < 2) return [];
  const headers = values.shift();

  return values
    .filter(row => row.some(cell => cell !== '' && cell !== null))
    .map(row => objectFromHeaders_(headers, row));
}

function getRowObject_(sheet, row) {
  const headers = getHeaders_(sheet);
  const values = sheet.getRange(row, 1, 1, sheet.getLastColumn()).getValues()[0];
  return objectFromHeaders_(headers, values);
}

function objectFromHeaders_(headers, values) {
  const obj = {};
  headers.forEach((header, index) => { obj[header] = values[index]; });
  return obj;
}

function getCustomerById_(customerId) {
  if (!customerId) return null;
  const customers = getDataObjects_(getSheet_(CREWSHEET.SHEETS.CUSTOMERS));
  return customers.find(customer => String(customer['Customer ID']).trim() === String(customerId).trim()) || null;
}

function getSetting_(key) {
  const rows = getDataObjects_(getSheet_(CREWSHEET.SHEETS.SETTINGS));
  const match = rows.find(row => String(row['Setting']).trim() === String(key).trim());
  return match ? match['Value'] : '';
}

function isTrueSetting_(key) {
  return String(getSetting_(key)).trim().toUpperCase() === 'TRUE';
}

function isValidEmail_(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
}

function toNumber_(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function formatMoney_(value) {
  const symbol = getSetting_('Currency Symbol') || '$';
  return symbol + toNumber_(value).toFixed(2);
}

function formatDate_(value) {
  if (!value) return '';
  const date = value instanceof Date ? value : new Date(value);
  if (isNaN(date.getTime())) return String(value);
  return Utilities.formatDate(date, Session.getScriptTimeZone(), 'yyyy-MM-dd');
}

function isDateWithin_(value, start, end) {
  if (!value) return false;
  const date = value instanceof Date ? value : new Date(value);
  if (isNaN(date.getTime())) return false;
  return date >= start && date <= end;
}

function formatList_(items, mapper) {
  if (!items.length) return '- None';
  return items.map(item => '- ' + mapper(item)).join('\n');
}
