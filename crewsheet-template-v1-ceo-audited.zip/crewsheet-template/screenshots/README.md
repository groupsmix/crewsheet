# Screenshots Placeholder

Add customer-facing screenshots here after converting the workbook to Google Sheets.

Recommended screenshots:

1. `01-make-copy.png`
2. `02-settings-tab.png`
3. `03-customers-tab.png`
4. `04-jobs-tab.png`
5. `05-quotes-tab.png`
6. `06-send-selected-quote.png`
7. `07-payments-tab.png`
8. `08-sunday-summary-email.png`

Use these screenshots in the sales page, support docs, and Loom walkthrough.
