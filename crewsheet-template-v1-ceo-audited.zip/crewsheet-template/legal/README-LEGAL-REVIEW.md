# Legal Review Notes

Before public launch, ask counsel to review:

- Customer license
- Website Terms
- Privacy Policy
- Refund Policy
- Data processing language
- Affiliate language
- Warranty disclaimers
- Payment/chargeback language
- Any claim about savings, revenue, or operational outcomes

Do not rely on this folder as legal advice. It is a product-ops draft only.
