# CrewSheet Customer License

This is a draft customer license. Have counsel review before public launch.

## License grant

When you buy CrewSheet, you receive a perpetual, worldwide, non-exclusive, non-transferable license to use and modify the CrewSheet template for your own cleaning business.

## You may

- Use CrewSheet inside your own cleaning business.
- Make copies for your own internal business use.
- Modify the Sheet and Apps Script for your own workflow.
- Add your own customer, job, quote, supply, and payment data.

## You may not

- Resell CrewSheet.
- Repackage CrewSheet as your own product.
- Share the template publicly.
- Sell modified versions of CrewSheet.
- Transfer your license to another business.
- Claim that CrewSheet is your original product.

## Digital product

CrewSheet is delivered as a digital template, Apps Script, and setup guide.

## No professional advice

CrewSheet is not legal, tax, accounting, financial, or business advice.

## No warranty

CrewSheet is provided as-is. You are responsible for reviewing the template, testing it, and confirming it fits your business needs.

## Data responsibility

You own and control the data you put into your copied Google Sheet. You are responsible for securing access to your Google account and Sheet.
