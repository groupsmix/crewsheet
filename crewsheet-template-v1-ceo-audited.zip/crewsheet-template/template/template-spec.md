# CrewSheet v1 Template Specification

## Required tabs

The v1 product has exactly six business tabs:

1. Customers
2. Jobs
3. Quotes
4. Supplies
5. Payments
6. Settings

## Customers

Purpose: Store customer records.

Required columns:

- Customer ID
- Customer Name
- Phone
- Email
- Address
- City
- Preferred Contact
- Customer Type
- Notes
- Created At
- Last Updated

Dropdowns:

- Preferred Contact: SMS, Email, Phone
- Customer Type: Residential, Commercial, Airbnb, Move-out, Other

## Jobs

Purpose: Track cleaning jobs from request to completion.

Required columns:

- Job ID
- Customer ID
- Customer Name
- Service Date
- Service Time
- Service Type
- Address
- Status
- Cleaner Assigned
- Estimated Hours
- Actual Hours
- Base Price
- Add-ons
- Total Price
- Paid?
- Notes
- Created At
- Last Updated

Formula:

- Total Price = Base Price + Add-ons

Apps Script also recalculates this when rows are edited.

Dropdowns:

- Service Type: Standard, Deep Clean, Move-out, Airbnb, Commercial
- Status: Requested, Quoted, Scheduled, Completed, Cancelled
- Paid?: Yes, No, Partial

## Quotes

Purpose: Prepare and email customer quotes.

Required columns:

- Quote ID
- Customer ID
- Job ID
- Quote Date
- Service Type
- Home Size Sq Ft
- Bedrooms
- Bathrooms
- Base Price
- Add-ons
- Discount
- Tax
- Total Quote
- Quote Status
- Stripe Link
- Email Sent?
- Notes

Formulas:

- Tax = max(0, Base Price + Add-ons - Discount) * Default Tax Rate
- Total Quote = max(0, Base Price + Add-ons - Discount) + Tax

Apps Script also recalculates this before sending a quote.

Dropdowns:

- Quote Status: Draft, Sent, Accepted, Rejected, Expired
- Email Sent?: Yes, No

Safety rules:

- `Test Mode` defaults to `TRUE`, so selected quote emails are sent to Business Email until the owner turns it off.
- `Block Placeholder Payment Links` defaults to `TRUE`, so quotes cannot be sent with `placeholder` or `example.com` payment URLs.
- Real customer quote sends require a confirmation prompt.

## Supplies

Purpose: Track supplies and reorder needs.

Required columns:

- Supply ID
- Item Name
- Category
- Current Quantity
- Minimum Quantity
- Unit
- Cost Per Unit
- Reorder Needed?
- Preferred Vendor
- Last Purchased
- Notes

Formula:

- Reorder Needed? = Yes when Current Quantity <= Minimum Quantity

Apps Script also recalculates this when rows are edited.

## Payments

Purpose: Track invoice/payment status.

Required columns:

- Payment ID
- Customer ID
- Job ID
- Invoice Date
- Amount Due
- Amount Paid
- Balance
- Payment Method
- Payment Status
- Stripe Link
- Paid Date
- Notes

Formula:

- Balance = max(0, Amount Due - Amount Paid)

Apps Script also recalculates this when rows are edited.

Dropdowns:

- Payment Method: Cash, Card, Zelle, Venmo, Check, Other
- Payment Status: Unpaid, Partial, Paid, Refunded

## Settings

Purpose: Store business-level configuration.

Required rows:

- Business Name
- Business Email
- Business Phone
- Default Tax Rate
- Default Currency
- Quote Email Subject
- Quote Email Footer
- Sunday Summary Recipient
- Stripe Payment Link Base URL
- Support Email
- Currency Symbol
- Test Mode
- Block Placeholder Payment Links
- Launch Approved?

Recommended defaults:

- Test Mode = TRUE
- Block Placeholder Payment Links = TRUE
- Launch Approved? = FALSE

## Conversion note

After uploading the `.xlsx` to Google Sheets, run these checks:

1. Formula cells compute correctly.
2. Dropdowns survived conversion.
3. Apps Script is pasted and saved.
4. CrewSheet menu appears after reload.
5. Health Check runs.
6. Test quote sends to Business Email while Test Mode is TRUE.
7. Real quote send is tested only with an email you control.
