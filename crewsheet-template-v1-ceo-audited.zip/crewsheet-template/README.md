# CrewSheet Template v1

CrewSheet v1 is a sellable Google Sheets delivery package for solo and small cleaning businesses.

## CEO status

This package is now suitable for a controlled soft launch after the seller replaces all placeholders, tests the Google Sheet conversion, pastes the Apps Script into the live Google Sheet, records the Loom walkthrough, and wires fulfillment.

Do not public-launch until `docs/launch-readiness-checklist.md` is complete.

## Included files

- `template/CrewSheet-v1-template.xlsx` — six-tab workbook template.
- `template/csv/` — CSV versions of each tab for Google Sheets import/rebuild.
- `template/template-spec.md` — workbook structure and field definitions.
- `apps-script/Code.gs` — Google Apps Script automation.
- `apps-script/appsscript.json` — recommended Apps Script project settings.
- `docs/setup-checklist.md` — buyer setup guide.
- `docs/glide-appsheet-runbook.md` — optional mobile app setup recipe.
- `docs/loom-walkthrough-script.md` — script for the required 15-minute walkthrough.
- `docs/buyer-delivery-email.md` — email to send after purchase.
- `docs/dfy-onboarding-checklist.md` — Done-For-You onboarding workflow.
- `docs/stripe-resend-fulfillment-plan.md` — fulfillment wiring plan.
- `docs/seller-launch-runbook.md` — seller-side launch steps.
- `docs/CEO-AUDIT-REPORT.md` — senior CEO audit and remediation notes.
- `legal/LICENSE-CUSTOMER.md` — customer license draft.

## What this v1 does

CrewSheet v1 helps a cleaning business manage:

1. Customers
2. Jobs
3. Quotes
4. Supplies
5. Payments
6. Settings

The Apps Script adds:

- CrewSheet menu inside Google Sheets.
- Safe test-mode quote email sending.
- Real customer quote email sending with confirmation.
- Placeholder payment-link blocking.
- Sunday summary email.
- Job total recalculation.
- Quote total recalculation.
- Payment balance recalculation.
- Supply reorder checks.
- Last-updated timestamp updates.
- A seller/customer health check.

## What v1 intentionally does not include

- No SMS/Twilio.
- No Pro tier.
- No redistributed Glide app.
- No fake testimonials.
- No payment processing inside the Sheet.
- No legal, tax, accounting, or business advice.
- No promise of revenue, savings, or operational outcomes.

## How to turn this into the customer Google Sheet

1. Open Google Drive.
2. Upload `template/CrewSheet-v1-template.xlsx`.
3. Open it with Google Sheets.
4. Review all formulas and dropdowns after conversion.
5. Rename it to `CrewSheet v1 Template`.
6. Open `Extensions -> Apps Script`.
7. Paste `apps-script/Code.gs`.
8. Set project settings using `apps-script/appsscript.json` as a reference.
9. Save.
10. Go back to the Sheet and reload.
11. Click `CrewSheet -> Install / Refresh Triggers`.
12. Click `CrewSheet -> Run Health Check`.
13. Keep `Settings -> Test Mode` as `TRUE` while testing.
14. Test quote email delivery to your own business email.
15. Set access to `Anyone with the link: Viewer` only when the template is ready.
16. Buyers should use `File -> Make a copy`.

## Replace before selling

- Google Sheet template link.
- Loom walkthrough URL.
- Stripe DIY checkout link.
- Stripe DFY checkout link.
- Support email.
- Founder/business info.
- Legal pages reviewed by counsel.
- Any placeholder payment links.
- Any placeholder domain or email addresses.

## Required seller smoke test

Before selling, complete this test from a clean Google account:

1. Buy through Stripe test mode or simulate purchase manually.
2. Receive the buyer delivery email.
3. Open the Google Sheet link.
4. Make a copy.
5. Fill Settings.
6. Install the script.
7. Run Health Check.
8. Send a test quote to Business Email.
9. Change `Test Mode` to `FALSE`.
10. Send one real test quote to an email you control.
11. Confirm Sunday summary sends.
12. Confirm all links in the delivery email work.
